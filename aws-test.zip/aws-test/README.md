# AWS-TEST

This is a Java project using Java 21 and Spring Boot.

## Authors

- [Aliaksei Tkachuk](https://github.com/aliakseiTk/)