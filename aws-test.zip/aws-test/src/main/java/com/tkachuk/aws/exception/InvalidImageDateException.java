package com.tkachuk.aws.exception;

public class InvalidImageDateException extends RuntimeException {

    public InvalidImageDateException(String message) {
        super(message);
    }
}
