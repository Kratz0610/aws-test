package com.tkachuk.aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
//class AwsProjectApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
